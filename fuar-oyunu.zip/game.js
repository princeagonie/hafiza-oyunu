/* =========================================================
   Atatürk, Ülkü ve Foxy — 50 Bölümlük Hafıza Oyunu
   Bağımlılık yok. Saf JavaScript.
   ========================================================= */
'use strict';

/* ---------------------------------------------------------
   AYARLAR
   --------------------------------------------------------- */
const CONFIG = {
  // Fuar sürümü: false.  Web/reklamlı sürüm: true.
  ADS_ENABLED: false,
  ADS_EVERY_N_LEVELS: 5,

  LEVELS: 50,
  FLIP_BACK_MS: 900,

  /* Ses dosyaları assets/sfx/ içinde. Hepsi CC0 (bkz. LISANSLAR.txt).
     Dosya yüklenemezse oyun kendi ürettiği seslere düşer — hiçbir
     tarayıcıda sessiz kalmaz. Değiştirmek istersen aynı isimle üzerine yaz. */
  SFX_DIR: 'assets/sfx/',
  SFX_FILES: { flip:'flip.ogg', match:'match.ogg', wrong:'wrong.ogg', level:'level.ogg' },
  MUSIC_FILE: 'music.mp3',
  MUSIC_VOLUME: 0.16,

  /* -------------------------------------------------------
     KART HAVUZU — tamamı özgün çizim (telifsiz)
     Fotoğrafa geçmek istersen karta  img:'assets/x.jpg'  ekle.
     ------------------------------------------------------- */
  POOL: [
    { id:'foxy',       art:'#art-foxy',       tint:'#FFE3C9', name:'Foxy',
      fact:'Foxy, Çankaya Köşkü’nde yaşayan köpekti. Ülkü’nün en yakın oyun arkadaşlarındandı.' },
    { id:'ulku',       art:'#art-ulku',       tint:'#FFD9E4', name:'Ülkü',
      fact:'Ülkü, Atatürk’ün manevi kızlarındandı. Çocukluğu Çankaya Köşkü’nde geçti.' },
    { id:'bayrak',     art:'#art-bayrak',     tint:'#FFD6D2', name:'Türk Bayrağı',
      fact:'Ay ve yıldız, Türk Bayrağı’nın simgesidir.' },
    { id:'kalpak',     art:'#art-kalpak',     tint:'#EADFCB', name:'Kalpak',
      fact:'Kalpak, Kurtuluş Savaşı yıllarının simgesi olan başlıktır.' },
    { id:'anitkabir',  art:'#art-anitkabir',  tint:'#CFEAF8', name:'Anıtkabir',
      fact:'Anıtkabir, Ankara’da Anıttepe’de bulunur ve 1953 yılında tamamlanmıştır.' },
    { id:'ucurtma',    art:'#art-ucurtma',    tint:'#DDF3D6', name:'Uçurtma',
      fact:'23 Nisan, dünyada çocuklara armağan edilen ilk bayramdır.' },
    { id:'kitap',      art:'#art-kitap',      tint:'#FFF0C2', name:'Yeni Harfler',
      fact:'Bugün kullandığımız Türk harfleri 1 Kasım 1928’de kabul edildi.' },
    { id:'tren',       art:'#art-tren',       tint:'#DCE2F8', name:'Tren',
      fact:'Cumhuriyet’in ilk yıllarında yurdun dört bir yanına demiryolu döşendi.' },
    { id:'vapur',      art:'#art-vapur',      tint:'#CFE9F5', name:'Bandırma Vapuru',
      fact:'Atatürk, 19 Mayıs 1919’da Bandırma Vapuru ile Samsun’a çıktı.' },
    { id:'saatkulesi', art:'#art-saatkulesi', tint:'#FBE7CF', name:'İzmir Saat Kulesi',
      fact:'İzmir Saat Kulesi, Konak Meydanı’nda bulunur ve 1901’de yapılmıştır.' },
    { id:'nazar',      art:'#art-nazar',      tint:'#D6ECFA', name:'Nazar Boncuğu',
      fact:'Nazar boncuğu, Anadolu’nun en tanınmış cam el sanatlarındandır.' },
    { id:'cay',        art:'#art-cay',        tint:'#FFE0D2', name:'Türk Çayı',
      fact:'Türkiye, dünyada kişi başına en çok çay tüketen ülkelerden biridir.' }
  ],

  CHEERS: ['Harika!', 'Süper!', 'Aferin!', 'Buldun!', 'Çok iyi!', 'Bravo!', 'Muhteşem!']
};

/* ---------------------------------------------------------
   BÖLÜM TASARIMI
   Zorluk yavaşça artar; hiçbir bölümde kaybetmek yok,
   yıldız sayısı performansı gösterir. 50 bölüm ~35 dakika.
   --------------------------------------------------------- */
function levelSpec(n){
  let pairs;
  if      (n <= 8)  pairs = 3;   // 6 kart
  else if (n <= 18) pairs = 4;   // 8 kart
  else if (n <= 30) pairs = 6;   // 12 kart
  else if (n <= 42) pairs = 8;   // 16 kart
  else              pairs = 10;  // 20 kart
  return { pairs: pairs, cols: pairs === 3 ? 3 : 4 };
}

function starThresholds(pairs){
  return { three: pairs + Math.ceil(pairs * 0.6), two: pairs + Math.ceil(pairs * 1.6) };
}

/* ---------------------------------------------------------
   Yardımcılar
   --------------------------------------------------------- */
const $  = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

function showScreen(id){
  $$('.screen').forEach(s => s.classList.toggle('is-active', s.id === id));
  document.body.classList.toggle('in-game', id === 'scr-game');
  window.scrollTo(0, 0);
}
function fmtTime(sec){ return Math.floor(sec/60) + ':' + String(sec%60).padStart(2,'0'); }
function pick(a){ return a[Math.floor(Math.random()*a.length)]; }

function shuffle(arr, rnd){
  const r = rnd || Math.random;
  for (let i = arr.length-1; i > 0; i--){
    const j = Math.floor(r() * (i+1));
    const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
  }
  return arr;
}
// Bölüm numarasına bağlı sabit rastgelelik: her bölüm hep aynı kart setini kullanır
function seeded(seed){
  let s = (seed * 2654435761) >>> 0;
  return function(){ s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

/* ---------------------------------------------------------
   İlerleme kaydı
   --------------------------------------------------------- */
const SAVE_KEY = 'ataturk-hafiza:v1';
let save = { stars:{}, unlocked:1, sound:true };

function loadSave(){
  try {
    const raw = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (raw && typeof raw === 'object'){
      save = Object.assign(save, raw);
      save.stars = save.stars || {};
      save.unlocked = Math.min(Math.max(save.unlocked|0, 1), CONFIG.LEVELS);
    }
  } catch(e){}
}
function persist(){
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch(e){}
}
function totalStars(){
  return Object.keys(save.stars).reduce((t,k) => t + save.stars[k], 0);
}

/* ---------------------------------------------------------
   SES
   assets/sfx/ içinde dosya varsa onu çalar; yoksa WebAudio ile
   üretilmiş sesleri kullanır. Her iki durumda da telifsiz.
   --------------------------------------------------------- */
const SFX = {
  files: {},
  ready: {},
  music: null,

  init(){
    Object.keys(CONFIG.SFX_FILES).forEach(k => {
      try {
        const a = new Audio(CONFIG.SFX_DIR + CONFIG.SFX_FILES[k]);
        a.preload = 'auto';
        a.addEventListener('canplaythrough', () => { this.ready[k] = true; }, { once:true });
        a.addEventListener('error', () => { this.ready[k] = false; }, { once:true });
        this.files[k] = a;
      } catch(e){}
    });
    try {
      // preload:'none' → 2.5 MB'lık müzik ancak oyuncu oynamaya başlayınca iner
      const m = new Audio(CONFIG.SFX_DIR + CONFIG.MUSIC_FILE);
      m.loop = true; m.volume = CONFIG.MUSIC_VOLUME; m.preload = 'none';
      m.addEventListener('error', () => { this.music = null; }, { once:true });
      this.music = m;
    } catch(e){ this.music = null; }
  },

  play(key, fallback){
    if (!save.sound) return;
    if (this.ready[key] && this.files[key]){
      try {
        const c = this.files[key].cloneNode();
        c.volume = 0.55;
        c.play().catch(() => { if (fallback) fallback(); });
        return;
      } catch(e){}
    }
    if (fallback) fallback();
  },

  musicOn(){
    if (!save.sound || !this.music) return;
    this.music.play().catch(() => {});
  },
  musicOff(){
    if (this.music){ try { this.music.pause(); } catch(e){} }
  }
};

/* ---- dosya yoksa devreye giren üretilmiş sesler ---- */
let actx = null;
function beep(freq, dur, type, vol){
  if (!save.sound) return;
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(vol || 0.16, actx.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
    o.connect(g).connect(actx.destination);
    o.start(); o.stop(actx.currentTime + dur + 0.02);
  } catch(e){}
}
const genFlip  = () => beep(520, 0.06, 'triangle', 0.10);
const genMatch = () => { beep(660, 0.10, 'sine'); setTimeout(() => beep(990, 0.18, 'sine'), 90); };
const genWrong = () => beep(170, 0.15, 'sawtooth', 0.09);
const genLevel = () => [523,659,784,1046,1318].forEach((f,i) => setTimeout(() => beep(f,0.24,'sine'), i*120));

const sndFlip  = () => SFX.play('flip',  genFlip);
const sndMatch = () => SFX.play('match', genMatch);
const sndWrong = () => SFX.play('wrong', genWrong);
const sndLevel = () => SFX.play('level', genLevel);

/* ---------------------------------------------------------
   Konfeti
   --------------------------------------------------------- */
const CONF_COLORS = ['#E23B3B','#F2B33D','#2FA69B','#6BBF59','#ffffff','#C8102E'];
function confetti(n){
  const box = $('#confetti');
  for (let i = 0; i < (n || 60); i++){
    const d = document.createElement('div');
    d.className = 'conf';
    d.style.left = Math.random()*100 + '%';
    d.style.background = pick(CONF_COLORS);
    d.style.animationDuration = (1.6 + Math.random()*1.6) + 's';
    d.style.animationDelay = (Math.random()*0.5) + 's';
    d.style.width  = (7 + Math.random()*7) + 'px';
    d.style.height = (10 + Math.random()*8) + 'px';
    box.appendChild(d);
    setTimeout(() => d.remove(), 4200);
  }
}

/* ---------------------------------------------------------
   Reklam kancası — fuar sürümünde kapalı
   --------------------------------------------------------- */
function adMaybe(level){
  if (!CONFIG.ADS_ENABLED) return Promise.resolve();
  if (level % CONFIG.ADS_EVERY_N_LEVELS !== 0) return Promise.resolve();
  // TODO(web sürümü): sdk.showAd('interstitial')
  return Promise.resolve();
}

/* ---------------------------------------------------------
   Oyun durumu
   --------------------------------------------------------- */
const state = {
  level: 1, spec: null, set: [], deck: [], open: [],
  matched: 0, moves: 0, seconds: 0, timer: null, locked: false
};

/* ---------------------------------------------------------
   BÖLÜM HARİTASI
   --------------------------------------------------------- */
function renderMap(){
  const box = $('#levels');
  box.innerHTML = '';
  for (let n = 1; n <= CONFIG.LEVELS; n++){
    const stars = save.stars[n] || 0;
    const locked = n > save.unlocked;

    const b = document.createElement('button');
    b.className = 'lvl' + (locked ? ' locked' : '') + (stars ? ' done' : '');
    b.type = 'button';
    b.disabled = locked;
    b.setAttribute('aria-label', 'Bölüm ' + n + (locked ? ' (kilitli)' : ''));

    let dots = '';
    for (let i = 0; i < 3; i++){
      dots += '<svg class="lvl-star' + (i < stars ? ' on' : '') + '"><use href="#art-star"></use></svg>';
    }
    b.innerHTML = locked
      ? '<span class="lvl-lock">🔒</span>'
      : '<span class="lvl-n">' + n + '</span><span class="lvl-stars">' + dots + '</span>';

    if (!locked) b.addEventListener('click', () => startLevel(n));
    box.appendChild(b);
  }
  $('#total-stars').textContent = totalStars();
}

/* ---------------------------------------------------------
   TAHTA
   --------------------------------------------------------- */
function faceFront(c){
  if (c.img) return '<img src="' + c.img + '" alt="' + c.name + '">';
  return '<span class="tint" style="--tint:' + c.tint + '"></span>' +
         '<svg class="art"><use href="' + c.art + '"></use></svg>';
}

function renderBoard(){
  const board = $('#board');
  board.innerHTML = '';
  board.dataset.cols = state.spec.cols;
  board.classList.toggle('dense', state.deck.length >= 16);

  state.deck.forEach(c => {
    const btn = document.createElement('button');
    btn.className = 'card';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Kapalı kart');
    btn.innerHTML =
      '<div class="card-inner">' +
        '<div class="face face-back"><svg class="paw"><use href="#art-back"></use></svg></div>' +
        '<div class="face face-front">' + faceFront(c) + '</div>' +
      '</div>';
    btn.addEventListener('click', () => onFlip(btn, c));
    board.appendChild(btn);
  });
}

function updateHud(){
  $('#hud-level').textContent = state.level;
  $('#hud-time').textContent  = fmtTime(state.seconds);
  $('#hud-pairs').textContent = state.matched + '/' + state.spec.pairs;
}

let tipTimer = null;
function showTip(text){
  const el = $('#tip');
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(tipTimer);
  tipTimer = setTimeout(() => el.classList.remove('show'), 1500);
}

function startTimer(){
  clearInterval(state.timer);
  state.timer = setInterval(() => {
    state.seconds++;
    $('#hud-time').textContent = fmtTime(state.seconds);
  }, 1000);
}

function onFlip(btn, card){
  if (state.locked) return;
  if (btn.classList.contains('is-open') || btn.classList.contains('is-done')) return;

  btn.classList.add('is-open');
  btn.setAttribute('aria-label', 'Açık kart: ' + card.name);
  state.open.push({ btn: btn, card: card });
  sndFlip();

  if (state.open.length < 2) return;

  state.moves++;
  const a = state.open[0], b = state.open[1];

  if (a.card.id === b.card.id){
    state.open = [];
    state.matched++;
    setTimeout(() => {
      a.btn.classList.add('is-done'); b.btn.classList.add('is-done');
      a.btn.disabled = true;          b.btn.disabled = true;
      sndMatch();
      confetti(12);
      showTip(pick(CONFIG.CHEERS) + ' ' + a.card.name);
      updateHud();
      if (state.matched === state.spec.pairs) setTimeout(finishLevel, 700);
    }, 250);
  } else {
    state.locked = true;
    sndWrong();
    setTimeout(() => { a.btn.classList.add('is-wrong'); b.btn.classList.add('is-wrong'); }, 220);
    setTimeout(() => {
      [a, b].forEach(x => {
        x.btn.classList.remove('is-open', 'is-wrong');
        x.btn.setAttribute('aria-label', 'Kapalı kart');
      });
      state.open = [];
      state.locked = false;
    }, CONFIG.FLIP_BACK_MS);
  }
}

/* ---------------------------------------------------------
   BÖLÜM AKIŞI
   --------------------------------------------------------- */
function startLevel(n){
  state.level   = n;
  state.spec    = levelSpec(n);
  // Bölümün kart seti sabit (aynı bölüm hep aynı kartlar), dizilim rastgele
  state.set     = shuffle(CONFIG.POOL.slice(), seeded(n)).slice(0, state.spec.pairs);
  state.deck    = shuffle(state.set.concat(state.set));
  state.open    = [];
  state.matched = 0;
  state.moves   = 0;
  state.seconds = 0;
  state.locked  = false;

  clearInterval(state.timer);
  $('#tip').classList.remove('show');
  renderBoard();
  updateHud();
  showScreen('scr-game');
  startTimer();
  SFX.musicOn();
}

function finishLevel(){
  clearInterval(state.timer);
  sndLevel();
  confetti(90);

  const t = starThresholds(state.spec.pairs);
  const stars = state.moves <= t.three ? 3 : (state.moves <= t.two ? 2 : 1);

  // kayıt
  const prev = save.stars[state.level] || 0;
  if (stars > prev) save.stars[state.level] = stars;
  if (state.level === save.unlocked && save.unlocked < CONFIG.LEVELS) save.unlocked++;
  persist();

  // ekran
  $('#win-level').textContent = 'Bölüm ' + state.level;
  $('#win-title').textContent = stars === 3 ? 'Mükemmel!' : (stars === 2 ? 'Çok iyi!' : 'Aferin!');
  $('#win-time').textContent  = fmtTime(state.seconds);
  $('#win-moves').textContent = state.moves;
  $$('#win-stars .star').forEach((s, i) => s.classList.toggle('on', i < stars));

  const f = pick(state.set);
  $('#fact-text').textContent = f.fact;
  $('#fact-use').setAttribute('href', f.art);

  const last = state.level >= CONFIG.LEVELS;
  $('#btn-next').textContent = last ? 'Bitir' : 'Sonraki Bölüm';

  adMaybe(state.level).then(() => showScreen('scr-win'));
}

function nextLevel(){
  if (state.level >= CONFIG.LEVELS){
    $('#final-stars').textContent = totalStars() + ' / ' + (CONFIG.LEVELS * 3);
    confetti(120);
    showScreen('scr-final');
    return;
  }
  startLevel(state.level + 1);
}

/* ---------------------------------------------------------
   Ana menü
   --------------------------------------------------------- */
function refreshStart(){
  const cont = $('#btn-continue');
  const done = totalStars() > 0;
  cont.hidden = !done;
  cont.querySelector('small').textContent = 'Bölüm ' + save.unlocked;

  const line = $('#best-line');
  if (done){
    line.hidden = false;
    line.innerHTML = 'Toplam yıldız: <b>' + totalStars() + '</b> / ' + (CONFIG.LEVELS * 3);
  } else {
    line.hidden = true;
  }
}

function updateSoundBtn(){
  $('#btn-sound').textContent = save.sound ? '🔊' : '🔇';
}

/* ---------------------------------------------------------
   Bağlantılar
   --------------------------------------------------------- */
$('#btn-play').addEventListener('click', () => {
  beep(560, 0.05, 'sine');            // sesi ilk dokunuşta uyandır
  SFX.musicOn();
  renderMap();
  showScreen('scr-map');
});

$('#btn-continue').addEventListener('click', () => {
  SFX.musicOn();
  startLevel(save.unlocked);
});

$('#btn-next').addEventListener('click', nextLevel);
$('#btn-retry').addEventListener('click', () => startLevel(state.level));

$('#btn-quit').addEventListener('click', () => {
  clearInterval(state.timer);
  renderMap();
  showScreen('scr-map');
});

$('#btn-sound').addEventListener('click', () => {
  save.sound = !save.sound;
  persist();
  updateSoundBtn();
  if (save.sound) SFX.musicOn(); else SFX.musicOff();
});

// data-go="ekran-id" olan bütün butonlar
$$('[data-go]').forEach(b => b.addEventListener('click', () => {
  const target = b.dataset.go;
  if (target === 'scr-map') renderMap();
  if (target === 'scr-start') refreshStart();
  showScreen(target);
}));

document.addEventListener('visibilitychange', () => {
  if (document.hidden){ clearInterval(state.timer); SFX.musicOff(); }
  else if ($('#scr-game').classList.contains('is-active')){ startTimer(); SFX.musicOn(); }
});

document.addEventListener('dblclick', e => e.preventDefault(), { passive:false });

/* ---------------------------------------------------------
   Başlat
   --------------------------------------------------------- */
loadSave();
SFX.init();
updateSoundBtn();
refreshStart();
document.body.classList.toggle('ads-on', CONFIG.ADS_ENABLED);
